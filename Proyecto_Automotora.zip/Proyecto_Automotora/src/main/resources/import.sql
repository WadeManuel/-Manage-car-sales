#Listado de Vendedores
INSERT INTO vendedores(id,nombre,apellido,antiguedad) VALUES(1,'Pedro','Perz',12);
INSERT INTO vendedores(id,nombre,apellido,antiguedad) VALUES(2,'Juanco','Chamba',17);
INSERT INTO vendedores(id,nombre,apellido,antiguedad) VALUES(3,'Alfre','Ramirez',19);
INSERT INTO vendedores(id,nombre,apellido,antiguedad) VALUES(4,'Alex','Robira',4);
INSERT INTO vendedores(id,nombre,apellido,antiguedad) VALUES(5,'Jose','Raul',5);

#Listado de Clientes
INSERT INTO clientes(id,nombre,direccion,telefono, create_at, vendedor_id) VALUES(1,'Emma','Avenida20',54204234,  NOW(), 2) ;
INSERT INTO clientes(id,nombre,direccion,telefono, create_at, vendedor_id) VALUES(2,'Papo','Avenida30',54753334, NOW(), 4);

#Listado de Automoviles Deportivos
INSERT INTO deportivos(id,matricula,marca,modelo,caballodefuerza,ano,kilometraje,precio,create_at) VALUES(1,32453,'Audi','R8V10 Plus',305,2019,360,295000.0,NOW());
INSERT INTO deportivos(id,matricula,marca,modelo,caballodefuerza,ano,kilometraje,precio,create_at) VALUES(2,22353,'Audi Sport','Quattro S1',305,2005,360,185000.0,NOW());
INSERT INTO deportivos(id,matricula,marca,modelo,caballodefuerza,ano,kilometraje,precio,create_at) VALUES(3,12453,'Audi S1','Hooinitron',305,2005,360,35000.0,NOW());
INSERT INTO deportivos(id,matricula,marca,modelo,caballodefuerza,ano,kilometraje,precio,create_at) VALUES(4,52453,'Audi Rs3','400 CV',30,2021,290,225000.0,NOW());
INSERT INTO deportivos(id,matricula,marca,modelo,caballodefuerza,ano,kilometraje,precio,create_at) VALUES(5,32253,'Audi ','R8',305,2005,360,450000.0,NOW());


#Listado de Utilitarios
INSERT INTO utilitario(id,matricula,marca,modelo,dueno,ano,kilometraje,precio,create_at) VALUES(1,324212,'Audi RS','e-Tron Gt','Marcos Acosta',2003,249,350000.0,NOW());
INSERT INTO utilitario(id,matricula,marca,modelo,dueno,ano,kilometraje,precio,create_at) VALUES(2,324333,'Audi','RS 5','Fernado-Federi',2002,276,335000.0,NOW());
INSERT INTO utilitario(id,matricula,marca,modelo,dueno,ano,kilometraje,precio,create_at) VALUES(3,324456,'Audi','TT4','Pablo Matos',2005,289,2350000.0,NOW());
INSERT INTO utilitario(id,matricula,marca,modelo,dueno,ano,kilometraje,precio,create_at) VALUES(4,324765,'Audi','RS7','Guillermo Calzado',2013,222,135000.0,NOW());

#Listado medios publicitarios
INSERT INTO medios(id,nombre,descripcion,tipo,deportivo_id,utilitario_id,create_at) VALUES(1,'observador','phone-13-ProMax','digital',1,1,NOW());
INSERT INTO medios(id,nombre,descripcion,tipo,deportivo_id,utilitario_id,create_at) VALUES(2,'observador','core-I7-7500','escritorio',2,2,NOW());

#Listado de Compras de los autos por los clientes
INSERT INTO compras(id,monto,cliente_id,deportivo_id,utilitario_id,create_at) VALUES(1,450000.0,2,5,1,NOW());
INSERT INTO compras(id,monto,cliente_id,deportivo_id,utilitario_id,create_at) VALUES(2,35000.0,1,1,2,NOW());

#Listado de Avisos
INSERT INTO avisos(id,vendedor_id,medio_id,deportivo_id,utilitario_id,create_at) VALUES(1,1,2,1,2,NOW());
INSERT INTO avisos(id,vendedor_id,medio_id,deportivo_id,utilitario_id,create_at) VALUES(2,2,1,2,4,NOW());
INSERT INTO avisos(id,vendedor_id,medio_id,deportivo_id,utilitario_id_id,create_at) VALUES(3,1,2,3,3,NOW());
INSERT INTO avisos(id,vendedor_id,medio_id,deportivo_id,utilitario_id,create_at) VALUES(4,2,1,4,1,NOW());

