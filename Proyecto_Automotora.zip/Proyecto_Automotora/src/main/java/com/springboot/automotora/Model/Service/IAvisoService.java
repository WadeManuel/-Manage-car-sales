package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Entity.Aviso;


import java.util.List;

public interface IAvisoService {

    public List<Aviso> findAll();

    public void save(Aviso aviso);

    public Aviso fineOne(Long id);

    public void eliminar(Long id);
}
