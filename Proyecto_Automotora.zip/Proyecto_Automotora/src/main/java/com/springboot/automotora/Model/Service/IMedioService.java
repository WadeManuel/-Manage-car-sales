package com.springboot.automotora.Model.Service;


import com.springboot.automotora.Model.Entity.MedioPublicitario;

import java.util.List;

public interface IMedioService {
    public List<MedioPublicitario> findAll();

    public void save(MedioPublicitario medioPublicitario);

    public MedioPublicitario fineOne(Long id);

    public void eliminar(Long id);

}
