package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.Vendedor;
import org.springframework.data.repository.CrudRepository;



public interface IVendedorDao extends CrudRepository<Vendedor,Long> {


}
