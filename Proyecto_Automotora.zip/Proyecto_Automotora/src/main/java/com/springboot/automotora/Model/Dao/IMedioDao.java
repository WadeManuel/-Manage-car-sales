package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.MedioPublicitario;
import org.springframework.data.repository.CrudRepository;

public interface IMedioDao extends CrudRepository<MedioPublicitario,Long> {
}
