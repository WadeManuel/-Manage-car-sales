package com.springboot.automotora.Model.Service;


import com.springboot.automotora.Model.Entity.CompraAuto;

import java.util.List;

public interface ICompraAutoService {

    public List<CompraAuto> findAll();

    public void save(CompraAuto compraAuto);

    public CompraAuto fineOne(Long id);

    public void eliminar(Long id);
}
