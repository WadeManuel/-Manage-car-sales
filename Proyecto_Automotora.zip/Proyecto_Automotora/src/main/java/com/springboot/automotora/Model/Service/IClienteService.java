package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Entity.Cliente;

import java.util.List;

public interface IClienteService {

    public List<Cliente> findAll();

    public void save(Cliente cliente);

    public Cliente fineOne(Long id);

    public void eliminar(Long id);
}
