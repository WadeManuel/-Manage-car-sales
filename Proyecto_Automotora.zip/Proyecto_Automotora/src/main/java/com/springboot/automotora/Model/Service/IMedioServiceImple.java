package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Dao.IMedioDao;
import com.springboot.automotora.Model.Entity.MedioPublicitario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IMedioServiceImple implements IMedioService{
    @Autowired
    private IMedioDao medioDao;

    @Override
    @Transactional(readOnly = true)
    public List<MedioPublicitario> findAll() {
        return (List<MedioPublicitario>) medioDao.findAll();
    }

    @Override
    @Transactional
    public void save(MedioPublicitario medioPublicitario) {
        medioDao.save(medioPublicitario);
    }

    @Override
    @Transactional(readOnly = true)
    public MedioPublicitario fineOne(Long id) {
        return medioDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        medioDao.deleteById(id);
    }
}
