package com.springboot.automotora.Model.Entity;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "medios")
public class MedioPublicitario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String descripcion;
    private String tipo;


    @ManyToOne
    @JoinColumn(name = "deportivo_id")
    private AutomovilDeportivo automovilDeportivo;

    @ManyToOne
    @JoinColumn(name = "utilitario_id")
    private AutomovilUtilitario automovilUtilitario;

    @Column(name = "create_at")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createAt;

    public AutomovilDeportivo getAutomovilDeportivo() {
        return automovilDeportivo;
    }

    public void setAutomovilDeportivo(AutomovilDeportivo automovilDeportivo) {
        this.automovilDeportivo = automovilDeportivo;
    }

    public AutomovilUtilitario getAutomovilUtilitario() {
        return automovilUtilitario;
    }

    public void setAutomovilUtilitario(AutomovilUtilitario automovilUtilitario) {
        this.automovilUtilitario = automovilUtilitario;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }
}
