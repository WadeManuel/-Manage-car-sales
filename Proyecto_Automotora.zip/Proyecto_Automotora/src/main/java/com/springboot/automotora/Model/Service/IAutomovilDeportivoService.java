package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Entity.AutomovilDeportivo;


import java.util.List;

public interface IAutomovilDeportivoService {
    public List<AutomovilDeportivo> findAll();

    public void save(AutomovilDeportivo automovilDeportivo);

    public AutomovilDeportivo fineOne(Long id);

    public void eliminar(Long id);
}
