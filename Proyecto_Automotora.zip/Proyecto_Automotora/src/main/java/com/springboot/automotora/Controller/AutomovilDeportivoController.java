package com.springboot.automotora.Controller;


import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import com.springboot.automotora.Model.Entity.Vendedor;
import com.springboot.automotora.Model.Service.IAutomovilDeportivoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

@Controller
@RequestMapping("/deportivo")
public class AutomovilDeportivoController {

    @Autowired
    private IAutomovilDeportivoService automovilDeportivoService;

    @RequestMapping(value = "/listar",method = RequestMethod.GET)
    public String listar(Model model){
        model.addAttribute("titulo","Listado de Autos Deportivos");
        model.addAttribute("deportivos",automovilDeportivoService.findAll());
        return "deportivo/listar";
    }

    @RequestMapping(value = "/form")
    public String crear(Map<String ,Object> model){
        AutomovilDeportivo automovilDeportivo=new AutomovilDeportivo();
        model.put("titulo","Formulario de Autos Deportivos");
        model.put("deportivo",automovilDeportivo);
        return "deportivo/form";
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public  String  guardar(AutomovilDeportivo automovilDeportivo){
        automovilDeportivoService.save(automovilDeportivo);
        return "redirect:listar";
    }

    @RequestMapping(value = "/form/{id}")
    public String editar(@PathVariable(value="id") Long id , Map<String , Object> model){
        AutomovilDeportivo automovilDeportivo=null;
        if (id > 0)
            automovilDeportivo = automovilDeportivoService.fineOne(id);
        else
            return "redirect:listar";
        model.put("deportivo",automovilDeportivo);
        model.put("titulo","Editar Datos de Autos Deportivos");
        return "deportivo/form";
    }

    @RequestMapping(value = "/eliminar/{id}")
    public String eliminar(@PathVariable (value = "id") Long id ){
        if (id > 0)
            automovilDeportivoService.eliminar(id);
        return "redirect:/deportivo/listar";

    }
}
