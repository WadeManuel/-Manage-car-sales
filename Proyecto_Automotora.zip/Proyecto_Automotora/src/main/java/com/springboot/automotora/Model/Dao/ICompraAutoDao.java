package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.CompraAuto;
import org.springframework.data.repository.CrudRepository;

public interface ICompraAutoDao extends CrudRepository<CompraAuto,Long> {

}
