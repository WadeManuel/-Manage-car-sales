package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Entity.Vendedor;

import java.util.List;

public interface IVendedorService {
    public List<Vendedor> findAll();

    public void save(Vendedor vendedor);

    public Vendedor fineOne(Long id);

    public void eliminar(Long id);
}
