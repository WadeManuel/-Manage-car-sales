package com.springboot.automotora.Controller;


import com.springboot.automotora.Model.Entity.*;
import com.springboot.automotora.Model.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/aviso")
public class AvisoController {

    @Autowired
    private IAvisoService avisoService;

    private IVendedorService vendedorService;
    private IMedioService medioService;

    private IAutomovilDeportivoService automovilDeportivoService;

    private IAutomovilUtilitarioService automovilUtilitarioService;

    @RequestMapping(value = "/listar",method = RequestMethod.GET)
    public String listar(Model model){
        model.addAttribute("titulo","Listado de Avisos de Autos");
        model.addAttribute("avisos", avisoService.findAll());
        return "aviso/listar";
    }

    @RequestMapping(value = "/form")
    public String crear(Map<String ,Object> model){
        Aviso aviso=new Aviso();

        List<Vendedor> vendedorList = vendedorService.findAll();
        List<MedioPublicitario> medioPublicitarioList = medioService.findAll();
        List<AutomovilDeportivo> deportivoList = automovilDeportivoService.findAll();
        List<AutomovilUtilitario> utilitarioList = automovilUtilitarioService.findAll();

        model.put("titulo","Formulario de Avisos");
        model.put("aviso",aviso);
        model.put("listaVendedores",vendedorList);
        model.put("listaMedios",medioPublicitarioList);
        model.put("listaDeportivos",deportivoList);
        model.put("listaUtilitarios",utilitarioList);
        return "aviso/form";
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public  String  guardar(Aviso aviso){
        avisoService.save(aviso);
        return "redirect:listar";
    }

    @RequestMapping(value = "/form/{id}")
    public String editar(@PathVariable(value="id") Long id , Map<String , Object> model){
        Aviso aviso=null;
        if (id > 0)
            aviso= avisoService.fineOne(id);
        else
            return "redirect:listar";
        List<Vendedor> vendedorList = vendedorService.findAll();
        List<MedioPublicitario> medioPublicitarioList = medioService.findAll();
        List<AutomovilDeportivo> deportivoList = automovilDeportivoService.findAll();
        List<AutomovilUtilitario>  utilitarioList= automovilUtilitarioService.findAll();

        model.put("aviso",aviso);
        model.put("titulo","Editar Datos de Avisos");
        model.put("listaVendedores",vendedorList);
        model.put("listaMedios",medioPublicitarioList);
        model.put("listaDeportivos",deportivoList);
        model.put("listaUtilitarios",utilitarioList);
        return "aviso/form";
    }

    @RequestMapping(value = "/eliminar/{id}")
    public String eliminar(@PathVariable (value = "id") Long id ){
        if (id > 0)
            medioService.eliminar(id);
        return "redirect:/aviso/listar";

    }
}
