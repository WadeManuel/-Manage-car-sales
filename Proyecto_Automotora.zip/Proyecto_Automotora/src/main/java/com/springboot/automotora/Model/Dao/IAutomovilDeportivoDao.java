package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface IAutomovilDeportivoDao extends CrudRepository<AutomovilDeportivo,Long> {

}
