package com.springboot.automotora.Model.Service;


import com.springboot.automotora.Model.Dao.ICompraAutoDao;
import com.springboot.automotora.Model.Entity.CompraAuto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ICompraAutoServiceImpl implements ICompraAutoService{

    @Autowired
    private ICompraAutoDao compraAutoDao;


    @Override
    @Transactional(readOnly = true)
    public List<CompraAuto> findAll(){
        return (List<CompraAuto>) compraAutoDao.findAll();
    }

    @Override
    @Transactional
    public void save(CompraAuto compraAuto) {
        compraAutoDao.save(compraAuto);

    }

    @Override
    @Transactional(readOnly = true)
    public CompraAuto fineOne(Long id) {
        return compraAutoDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        compraAutoDao.deleteById(id);
    }
}
