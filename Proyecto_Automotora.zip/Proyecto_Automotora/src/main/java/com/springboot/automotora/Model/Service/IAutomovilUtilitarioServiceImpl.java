package com.springboot.automotora.Model.Service;



import com.springboot.automotora.Model.Dao.IAutomovilUtilitarioDao;
import com.springboot.automotora.Model.Entity.AutomovilUtilitario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IAutomovilUtilitarioServiceImpl implements IAutomovilUtilitarioService{

    @Autowired
    private IAutomovilUtilitarioDao automovilUtilitarioDao;

    @Override
    @Transactional(readOnly = true)
    public List<AutomovilUtilitario> findAll() {
        return  (List<AutomovilUtilitario>) automovilUtilitarioDao.findAll();
    }

    @Override
    @Transactional
    public void save(AutomovilUtilitario automovilUtilitario) {
        automovilUtilitarioDao.save(automovilUtilitario);
    }

    @Override
    @Transactional(readOnly = true)
    public AutomovilUtilitario fineOne(Long id) {
        return automovilUtilitarioDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        automovilUtilitarioDao.deleteById(id);
    }
}
