package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Dao.IAvisoDao;
import com.springboot.automotora.Model.Entity.Aviso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IAvisoServiceImpl implements IAvisoService{

    @Autowired
    private IAvisoDao avisoDao;

    @Override
    @Transactional(readOnly = true)
    public List<Aviso> findAll() {
        return (List<Aviso>) avisoDao.findAll();
    }

    @Override
    @Transactional
    public void save(Aviso aviso) {
        avisoDao.save(aviso);
    }

    @Override
    @Transactional(readOnly = true)
    public Aviso fineOne(Long id) {
        return avisoDao.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Long id) {
        avisoDao.deleteById(id);
    }
}
