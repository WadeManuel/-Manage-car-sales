package com.springboot.automotora.Controller;

import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import com.springboot.automotora.Model.Entity.AutomovilUtilitario;
import com.springboot.automotora.Model.Service.IAutomovilUtilitarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

@Controller
@RequestMapping("/utilitario")
public class AutomovilUtilitarioController {

    @Autowired
    private IAutomovilUtilitarioService automovilUtilitarioService;

    @RequestMapping(value = "/listar",method = RequestMethod.GET)
    public String listar(Model model){
        model.addAttribute("titulo","Listado de Autos Utilitarios");
        model.addAttribute("utilitarios",automovilUtilitarioService.findAll());
        return "utilitario/listar";
    }

    @RequestMapping(value = "/form")
    public String crear(Map<String ,Object> model){
        AutomovilUtilitario automovilUtilitario=new AutomovilUtilitario();
        model.put("titulo","Formulario de Autos Utilitarios");
        model.put("utilitario",automovilUtilitario);
        return "utilitario/form";
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public  String  guardar(AutomovilUtilitario automovilUtilitario){
        automovilUtilitarioService.save(automovilUtilitario);
        return "redirect:listar";
    }

    @RequestMapping(value = "/form/{id}")
    public String editar(@PathVariable(value="id") Long id , Map<String , Object> model){
        AutomovilUtilitario automovilUtilitario=null;
        if (id > 0)
            automovilUtilitario = automovilUtilitarioService.fineOne(id);
        else
            return "redirect:listar";
        model.put("utilitario",automovilUtilitario);
        model.put("titulo","Editar Datos de Autos Utilitarios");
        return "utilitario/form";
    }

    @RequestMapping(value = "/eliminar/{id}")
    public String eliminar(@PathVariable (value = "id") Long id ){
        if (id > 0)
            automovilUtilitarioService.eliminar(id);
        return "redirect:/utilitario/listar";

    }
}
