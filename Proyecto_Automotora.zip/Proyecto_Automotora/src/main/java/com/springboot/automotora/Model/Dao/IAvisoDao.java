package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.Aviso;
import org.springframework.data.repository.CrudRepository;

public interface IAvisoDao extends CrudRepository<Aviso,Long> {
}
