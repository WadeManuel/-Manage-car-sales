package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Dao.IAutomovilDeportivoDao;
import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IAutomovilDeportivoServiceImpl implements IAutomovilDeportivoService{

    @Autowired
    private IAutomovilDeportivoDao automovilDeportivoDao;


    @Override
    @Transactional(readOnly = true)
    public List<AutomovilDeportivo> findAll() {
        return (List<AutomovilDeportivo>) automovilDeportivoDao.findAll();
    }

    @Override
    @Transactional
    public void save(AutomovilDeportivo automovilDeportivo) {
        automovilDeportivoDao.save(automovilDeportivo);
    }

    @Override
    @Transactional(readOnly = true)
    public AutomovilDeportivo fineOne(Long id) {
        return automovilDeportivoDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        automovilDeportivoDao.deleteById(id);
    }
}
