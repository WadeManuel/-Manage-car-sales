package com.springboot.automotora.Model.Dao;

import com.springboot.automotora.Model.Entity.AutomovilUtilitario;
import org.springframework.data.repository.CrudRepository;

public interface IAutomovilUtilitarioDao extends CrudRepository<AutomovilUtilitario,Long> {
}
