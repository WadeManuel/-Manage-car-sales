package com.springboot.automotora.Model.Service;


import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import com.springboot.automotora.Model.Entity.AutomovilUtilitario;

import java.util.List;

public interface IAutomovilUtilitarioService {
    public List<AutomovilUtilitario> findAll();

    public void save(AutomovilUtilitario automovilUtilitario);

    public AutomovilUtilitario fineOne(Long id);

    public void eliminar(Long id);
}
