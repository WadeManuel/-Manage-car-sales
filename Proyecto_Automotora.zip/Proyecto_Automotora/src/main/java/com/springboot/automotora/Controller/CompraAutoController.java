package com.springboot.automotora.Controller;

import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import com.springboot.automotora.Model.Entity.AutomovilUtilitario;
import com.springboot.automotora.Model.Entity.Cliente;
import com.springboot.automotora.Model.Entity.CompraAuto;
import com.springboot.automotora.Model.Service.IAutomovilDeportivoService;
import com.springboot.automotora.Model.Service.IAutomovilUtilitarioService;
import com.springboot.automotora.Model.Service.IClienteService;
import com.springboot.automotora.Model.Service.ICompraAutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/compra")
public class CompraAutoController{

    @Autowired
    private ICompraAutoService compraAutoService;
    private IClienteService clienteService;

    private IAutomovilDeportivoService automovilDeportivoService;

    private IAutomovilUtilitarioService automovilUtilitarioService;

    @RequestMapping(value = "/listar",method = RequestMethod.GET)
    public String listar(Model model){
        model.addAttribute("titulo","Listado de las compra de auto por cliente");
        model.addAttribute("compras",compraAutoService.findAll());
        return "compra/listar";
    }

    @RequestMapping(value = "/form")
    public String crear(Map<String ,Object> model){
        CompraAuto compraAuto = new CompraAuto();

        List<Cliente> clienteList=clienteService.findAll();
        List<AutomovilDeportivo> deportivoList = automovilDeportivoService.findAll();
        List<AutomovilUtilitario> utilitarioList = automovilUtilitarioService.findAll();

        model.put("titulo","Formulario de Compras Auto");
        model.put("compra",compraAuto);
        model.put("listaClientes",clienteList);
        model.put("listaDeportivos",deportivoList);
        model.put("listaUtilitarios",utilitarioList);
        return "compra/form";
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public  String  guardar(CompraAuto compraAuto){
        compraAutoService.save(compraAuto);
        return "redirect:listar";
    }

    @RequestMapping(value = "/form/{id}")
    public String editar(@PathVariable(value="id") Long id , Map<String , Object> model){
        CompraAuto compraAuto = null;
        if (id > 0)
            compraAuto = compraAutoService.fineOne(id);
        else
            return "redirect:listar";
        List<Cliente> clienteList = clienteService.findAll();
        List<AutomovilDeportivo> deportivoList = automovilDeportivoService.findAll();
        List<AutomovilUtilitario>  utilitarioList= automovilUtilitarioService.findAll();

        model.put("compra",compraAuto);
        model.put("titulo","Editar Datos de lo Compra Auto");
        model.put("listaClientes",clienteList);
        model.put("listaDeportivos",deportivoList);
        model.put("listaUtilitarios",utilitarioList);
        return "compra/form";
    }

    @RequestMapping(value = "/eliminar/{id}")
    public String eliminar(@PathVariable (value = "id") Long id ){
        if (id > 0)
            compraAutoService.eliminar(id);
        return "redirect:/compra/listar";

    }
}
