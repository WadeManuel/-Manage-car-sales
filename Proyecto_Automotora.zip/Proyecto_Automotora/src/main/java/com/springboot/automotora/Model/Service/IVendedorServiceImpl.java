package com.springboot.automotora.Model.Service;

import com.springboot.automotora.Model.Dao.IVendedorDao;
import com.springboot.automotora.Model.Entity.Vendedor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class IVendedorServiceImpl implements IVendedorService{

    @Autowired
    private IVendedorDao vendedorDao;

    @Override
    @Transactional(readOnly = true)
    public List<Vendedor> findAll() {
        return (List<Vendedor>) vendedorDao.findAll();
    }

    @Override
    @Transactional
    public void save(Vendedor vendedor) {
        vendedorDao.save(vendedor);
    }

    @Override
    @Transactional(readOnly = true)
    public Vendedor fineOne(Long id) {
        return vendedorDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        vendedorDao.deleteById(id);
    }
}
