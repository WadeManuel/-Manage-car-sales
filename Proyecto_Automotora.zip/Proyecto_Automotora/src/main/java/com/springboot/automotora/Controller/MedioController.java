package com.springboot.automotora.Controller;

import com.springboot.automotora.Model.Entity.*;
import com.springboot.automotora.Model.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/medio")
public class MedioController {

    @Autowired
    private IMedioService medioService;
    @Autowired
    private IAutomovilDeportivoService automovilDeportivoService;
    @Autowired
    private IAutomovilUtilitarioService automovilUtilitarioService;



    @RequestMapping(value = "/listar",method = RequestMethod.GET)
    public String listar(Model model){
        model.addAttribute("titulo","Listado de Medios Publicitarios");
        model.addAttribute("medio",medioService.findAll());
        return "medio/listar";
    }

    @RequestMapping(value = "/form")
    public String crear(Map<String ,Object> model){
        MedioPublicitario medioPublicitario=new MedioPublicitario();
        List<AutomovilDeportivo> automovilDeportivoList=automovilDeportivoService.findAll();
        List<AutomovilUtilitario> automovilUtilitarioList=automovilUtilitarioService.findAll();
        model.put("titulo","Formulario de Medios Publicitarios");
        model.put("medio",medioPublicitario);
        model.put("listaDeportivos",automovilDeportivoList);
        model.put("listaUtilitarios",automovilUtilitarioList);
        return "medio/form";
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public  String  guardar(MedioPublicitario medioPublicitario){
        medioService.save(medioPublicitario);
        return "redirect:listar";
    }

    @RequestMapping(value = "/form/{id}")
    public String editar(@PathVariable(value="id") Long id , Map<String , Object> model){
        MedioPublicitario medioPublicitario=null;
        if (id > 0)
            medioPublicitario = medioService.fineOne(id);
        else
            return "redirect:listar";
        List<AutomovilDeportivo> automovilDeportivoList=automovilDeportivoService.findAll();
        List<AutomovilUtilitario> automovilUtilitarioList=automovilUtilitarioService.findAll();
        model.put("medio",medioPublicitario);
        model.put("titulo","Editar Datos del  Medios Publicitarios");
        model.put("listaDeportivos",automovilDeportivoList);
        model.put("listaUtilitarios",automovilUtilitarioList);
        return "medio/form";
    }

    @RequestMapping(value = "/eliminar/{id}")
    public String eliminar(@PathVariable (value = "id") Long id ){
        if (id > 0)
            medioService.eliminar(id);
        return "redirect:/medio/listar";

    }

}
