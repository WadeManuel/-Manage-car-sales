package com.springboot.automotora.Model.Entity;

import com.springboot.automotora.Model.Entity.AutomovilDeportivo;
import com.springboot.automotora.Model.Entity.AutomovilUtilitario;
import com.springboot.automotora.Model.Entity.Cliente;
import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "compras")
public class CompraAuto implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private float monto;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "deportivo_id")
    private AutomovilDeportivo automovilDeportivo;
    @ManyToOne
    @JoinColumn(name = "utilitario_id")
    private AutomovilUtilitario automovilUtilitario;



    @Column(name = "create_at")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public AutomovilDeportivo getAutomovilDeportivo() {
        return automovilDeportivo;
    }

    public void setAutomovilDeportivo(AutomovilDeportivo automovilDeportivo) {
        this.automovilDeportivo = automovilDeportivo;
    }

    public AutomovilUtilitario getAutomovilUtilitario() {
        return automovilUtilitario;
    }

    public void setAutomovilUtilitario(AutomovilUtilitario automovilUtilitario) {
        this.automovilUtilitario = automovilUtilitario;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }
}
