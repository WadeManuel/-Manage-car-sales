package com.springboot.automotora.Model.Entity;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "avisos")
public class Aviso implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;


    @ManyToOne
    @JoinColumn(name = "vendedor_id")
    private Vendedor vendedor;

    @ManyToOne
    @JoinColumn(name = "medio_id")
    private MedioPublicitario medioPublicitario;

    @ManyToOne
    @JoinColumn(name = "deportivo_id")
    private AutomovilDeportivo automovilDeportivo;

    @ManyToOne
    @JoinColumn(name = "utilitario_id")
    private AutomovilUtilitario automovilUtilitario;



    @Column(name = "create_at")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createAt;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public MedioPublicitario getMedioPublicitario() {
        return medioPublicitario;
    }

    public void setMedioPublicitario(MedioPublicitario medioPublicitario) {
        this.medioPublicitario = medioPublicitario;
    }

    public AutomovilDeportivo getAutomovilDeportivo() {
        return automovilDeportivo;
    }

    public void setAutomovilDeportivo(AutomovilDeportivo automovilDeportivo) {
        this.automovilDeportivo = automovilDeportivo;
    }

    public AutomovilUtilitario getAutomovilUtilitario() {
        return automovilUtilitario;
    }

    public void setAutomovilUtilitario(AutomovilUtilitario automovilUtilitario) {
        this.automovilUtilitario = automovilUtilitario;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }
}
